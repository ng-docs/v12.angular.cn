declare module 'jasmine-core/lib/jasmine-core/jasmine.js';
