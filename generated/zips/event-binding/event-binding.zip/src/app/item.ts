export class Item {
  name = '';
}

