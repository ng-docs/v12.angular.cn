import { Injectable } from '@angular/core';

@Injectable()
export class OptionalService {
}

// This service isn't provided anywhere.
