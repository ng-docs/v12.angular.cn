import { Component } from '@angular/core';

@Component({
  selector: 'app-precedence',
  templateUrl: './precedence.component.html',
  styles: []
})

export class PrecedenceComponent {
  title = 'Pipes and Precedence';
}
