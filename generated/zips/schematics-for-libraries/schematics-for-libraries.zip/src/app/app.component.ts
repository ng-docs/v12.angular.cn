import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h2>Library Schematics</h2>
  `,
  styles: []
})
export class AppComponent {
  title = 'schematics-for-libraries';
}
