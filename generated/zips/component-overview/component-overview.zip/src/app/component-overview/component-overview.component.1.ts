import { Component } from '@angular/core';

@Component({
  selector: 'app-component-overview',
  template: '<h1>Hello World!</h1>',
})

export class ComponentOverviewComponent {

}

